# Web Flask

This is a project that shows how dynamic web pages can be built with the Flask web application module. See [TASKS](TASKS.md) for the requirements of this project.
